#include <iostream>
#include "log4qt/src/logger.h"
#include "log4qt/src/propertyconfigurator.h"
#include"log4qt/src/patternlayout.h"
#include"log4qt/src/consoleappender.h"
#include"log4qt/src/fileappender.h"
#include"log4qt/src/loggerrepository.h"
#include<QApplication>
#include<QDebug>



using namespace std;

int main(int argc, char *argv[])
{
     QApplication a(argc, argv);
    qDebug()<<a.applicationDirPath();
    Log4Qt::Logger* logger = Log4Qt::Logger::rootLogger();
    // 创建PatternLayout（根据模式字符串输出日志事件）
    Log4Qt::PatternLayout *layout = new Log4Qt::PatternLayout();
    // 设置标头信息
    layout->setHeader("----- start -----");
    // 设置页脚信息
    layout->setFooter("----- end -----");
    // 设置转换模式
    layout->setConversionPattern("%d{yyyy-MM-dd hh:mm:ss} [%p] - %m%n");
    // 激活Layout
    layout->activateOptions();
    // 创建ConsoleAppender
//    Log4Qt::ConsoleAppender *appender = new Log4Qt::ConsoleAppender(layout, Log4Qt::ConsoleAppender::STDOUT_TARGET);
       Log4Qt::FileAppender *appender = new Log4Qt::FileAppender(layout,"../log/log.txt");
    appender->activateOptions();
    logger->addAppender(appender);
    logger->setLevel(Log4Qt::Level::DEBUG_INT);
    logger->debug("hello debug");
    logger->info("hello info");
    logger->warn("hello warn");
    // 关闭 logger
    logger->removeAllAppenders();
    logger->loggerRepository()->shutdown();
    return a.exec();
}

