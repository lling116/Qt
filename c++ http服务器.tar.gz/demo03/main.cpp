#include <iostream>
#include "http_server.h"
#include<memory>
#include<boost/algorithm/string.hpp>

using namespace std;


int msplit()
{
    string test = "i am a student,you are a teacher!";
    vector<string> vec;
    boost::split(vec, test,boost::is_any_of(","), boost::token_compress_on);
    for(int i = 0; i < vec.size(); ++i)
    {
        cout<<vec[i]<<endl;
    }
    return 0;
}


bool agv_task(std::string url, std::string body, mg_connection *c, OnRspCallback rsp_callback,http_message *http_req)
{
        std::string req_str = std::string(http_req->message.p, http_req->message.len); //得到
        auto pos1 = req_str.find("=");
        std::cout<<"pos="<<pos1<<std::endl;
        auto pos2 = req_str.find("H");
        std::cout<<"pos="<<pos2<<std::endl;
        string tmp_str = req_str.substr(pos1+1,pos2-pos1-1);
        std::cout<<"tmp_str===="<<tmp_str<<std::endl;
        vector<string> vec;
        boost::split(vec, tmp_str,boost::is_any_of(","), boost::token_compress_on);
        for(int i = 0; i < vec.size(); ++i)
        {
            cout<<"vec["<<i<<"]="<<vec[i]<<endl;
        }
    rsp_callback(c, "rsp1");
    return true;
}


bool handle_fun1(std::string url, std::string body, mg_connection *c, OnRspCallback rsp_callback,http_message *http_req)
{
    // do sth
//    std::cout << "handle fun1" << std::endl;
//    std::cout << "url: " << url << std::endl;
//    std::cout << "body: " << body << std::endl;
    rsp_callback(c, "rsp1");

    return true;
}

bool handle_fun2(std::string url, std::string body, mg_connection *c, OnRspCallback rsp_callback,http_message *http_req)
{
    // do sth
//    std::cout << "handle fun2" << std::endl;
//    std::cout << "url: " << url << std::endl;
//    std::cout << "body: " << body << std::endl;

    rsp_callback(c, "rsp2");

    return true;
}


int main(int argc, char *argv[])
{
    std::string port = "8000";
//    msplit();
    auto http_server = std::shared_ptr<HttpServer>(new HttpServer);
    http_server->Init(port);
    // add handler
    http_server->AddHandler("/api/fun1", handle_fun1);
    http_server->AddHandler("/api/fun2", handle_fun2);
    http_server->AddHandler("/api/agv_task", agv_task);
    http_server->RemoveHandler("/api/fun3");
    // http_server->RemoveHandler("/api/fun3");
    http_server->Start();

    return 0;
}
