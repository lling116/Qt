#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QTcpSocket>
#include<QPushButton>
#include<QByteArray>
#include<QTcpServer>
#include<QList>
#include<QTime>

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = 0);
    ~Widget();
    void init_server();
    void delay_msec(unsigned int  msec);

private:
    QTcpSocket *m_socket;
    QTcpSocket *server_socket;
    QTcpServer *m_server;
    QPushButton *btn;
    //将字符转16进制
    QByteArray QString2Hex(QString str);
   //将1-9 a-f字符转化为对应的整数;
    int ConvertHexChar(char ch);
    QString line;
    void create_newClient(QString msg);
    QTcpSocket *mSocket1 ;
    QTcpSocket *mSocket2 ;
    QTcpSocket *mSocket3 ;

     QTcpSocket *tempSocket;
     QList<QTcpSocket*> socketList;


private slots:
    void sendFile();
    void getMessage();
    void getReplay();

};

#endif // WIDGET_H
