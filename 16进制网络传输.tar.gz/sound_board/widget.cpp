#include "widget.h"
#include<QDebug>
#include<QFile>
#include<QTextStream>
#include<QHostAddress>
#include<iostream>
#include<QThread>


Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
      init_server();
       tempSocket= new QTcpSocket(this);
       for(int i = 0 ;i<2;i++)
       {
           socketList << new QTcpSocket(this);
       }
}

Widget::~Widget()
{

}

void Widget::init_server()
{
    m_server = new QTcpServer(this);
    m_server->listen(QHostAddress::Any,6060);
    connect(m_server,SIGNAL(newConnection()),this,SLOT(getMessage()));
//    server_socket = m_server->nextPendingConnection();
    //   connect(server_socket,SIGNAL(readyRead()),this,SLOT(getReplay()));
}

void Widget::delay_msec(unsigned int  msec)
{
    QTime timer = QTime::currentTime();
    QTime now ;
    do{
        now = QTime::currentTime();
    }while(timer.msecsTo(now)<=msec);
}

QByteArray Widget::QString2Hex(QString str)
{
    QByteArray sendData;
    int highHexData,lowHexData,hexData;
    int hexDataLen = 0;
    int len = str.length();
    sendData.resize(len/2);
    char lstr,hstr;
    for(int i=0;i<len;)
    {
        hstr = str[i].toLatin1();
        if(hstr==' ')
        {
            i++;
            continue;
        }
        i++;
        if(i>=len)
            break;
        lstr = str[i].toLatin1();
        highHexData = ConvertHexChar(hstr);
        lowHexData = ConvertHexChar(lstr);
        if((highHexData==16)||(lowHexData==16))
            break;
        else
            hexData = highHexData*16 +lowHexData;
        i++;

        sendData[hexDataLen] = (char)hexData;
        hexDataLen++;
    }

    sendData.resize(hexDataLen);
    return sendData;
}

int Widget::ConvertHexChar(char ch)
{
    if((ch >= '0') && (ch <= '9'))
         return ch-'0';

    else if((ch >= 'A') && (ch <= 'F'))
         return ch-'A'+10;

    else if((ch >= 'a') && (ch <= 'f'))
         return ch-'a'+10;

    else return (-1);
}

void Widget::create_newClient(QString msg)
{
    QString file_name="/home/wang/"+msg+".txt";
    QFile file(file_name);
    if(!file.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        qDebug()<<file_name<<"文件打开失败123"<<"error";
        return;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        line = in.readLine();
    }
     QByteArray data =  QString2Hex(line);


     if(msg=="800" || msg=="900" || msg=="1000")
     {
        socketList[0] ->connectToHost("192.168.167.100",5000);
        socketList[0]->write(data);
     }
     else{
         socketList[1] ->connectToHost("192.168.167.101",5001);
         socketList[1]->write(data);
     }

}

void Widget::sendFile()
{
    QFile file("/home/wang/1301.txt");
    if(!file.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        qDebug()<<"文件打开失败";
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        line = in.readLine();
    }
    QByteArray data =  QString2Hex(line);
    m_socket->write(data);
}

void Widget::getMessage()
{
  server_socket = m_server->nextPendingConnection();
  connect(server_socket,SIGNAL(readyRead()),this,SLOT(getReplay()));
}

void Widget::getReplay()
{
    if(server_socket->bytesAvailable()>0)
    {

        QByteArray datagram;
        datagram.resize(server_socket->bytesAvailable());
        server_socket->read(datagram.data(),datagram.size());
        QString msg = datagram.data();
        create_newClient( msg);
    }
}
