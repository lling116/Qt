<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Dialog</name>
    <message>
        <location filename="QtLanguage.ui" line="14"/>
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
    <message>
        <location filename="QtLanguage.ui" line="26"/>
        <source>TextLabel</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="QtLanguage.ui" line="42"/>
        <source>PushButton</source>
        <translation>按钮</translation>
    </message>
    <message>
        <location filename="QtLanguage.ui" line="55"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="QtLanguage.ui" line="68"/>
        <source>简体中文</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
