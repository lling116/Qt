#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QNetworkAccessManager>
#include<QNetworkRequest>
#include<QNetworkReply>

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = 0);
    ~Widget();
public slots:
    void finishedSlot(QNetworkReply*);

private:
    QNetworkAccessManager *accessManager;
    QNetworkRequest request;
     QNetworkReply* reply;
};

#endif // WIDGET_H
