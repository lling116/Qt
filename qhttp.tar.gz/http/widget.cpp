#include "widget.h"
#include<QUrl>
#include<QByteArray>
#include<QDebug>


Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    accessManager = new QNetworkAccessManager(this);
    connect(accessManager,SIGNAL(finished(QNetworkReply*)),this,SLOT(finishedSlot(QNetworkReply*)));
    request.setUrl(QUrl("http://127.0.0.1:5000"));
    //get请求
//    reply = accessManager->get(request);
    //post
/*===========================表单数据发送=========================================*/
//    request.setHeader(QNetworkRequest::ContentTypeHeader,QVariant("application/json"));
//    QByteArray postData;
//    postData.append("username=admin&password=123456"); //这样是表单数据
/*===========================json数据发送 另外还可以利用QJSON=========================================*/
    request.setHeader(QNetworkRequest::ContentTypeHeader,QVariant("application/json"));
    QByteArray array("{\"userid\":\"1538822184@qq.com\"}"); //这是json
    reply = accessManager->post(request, array);
}
Widget::~Widget()
{

}

void Widget::finishedSlot(QNetworkReply *)
{
    if (reply->error() == QNetworkReply::NoError)
         {
             QByteArray bytes = reply->readAll();
             qDebug() << bytes;
         }
         else
         {
             qDebug() << "finishedSlot errors here";
             qDebug( "found error .... code: %d\n", (int)reply->error());
             qDebug(qPrintable(reply->errorString()));
         }
         reply->deleteLater();
}
